# STAGE 1 — ONLY AFTER I HAVE EXPLICITLY CHOSEN A SITE-WIDE CONCEPT

Read `AGENTS.md`, `docs/00_STATUS_AND_SOURCE_OF_TRUTH.md`, `docs/03_NON_GENERIC_ART_DIRECTION.md`, `docs/04_CREATIVE_CONCEPT_APPROVAL.md`, `docs/05_EXPERIENCE_ARCHITECTURE.md`, `docs/08_MOBILE_UX_AND_MOTION.md`, `docs/09_DESIGN_SYSTEM_AND_ASSET_POLICY.md` and the current decision log.

The concept I selected is: [OWNER PASTES EXACT APPROVED CONCEPT HERE].

**Do not code or generate images.** Convert the selected concept into an **art-direction and interaction blueprint**:
1. A single-paragraph creative thesis; exactly what makes it unlike ClickIt Zoya.
2. Original layout grammar and navigation (curated intro -> free exploration) for mobile and desktop.
3. Five high-quality scene descriptions including at least TWO signatures NOT part of 22 discoveries; for each: visual composition, controlled motion, interaction, emotional job, originality argument, performance and reduced-motion fallback.
4. A responsive layout plan at 320, 390, 430, 768 and 1440px. No repetitive rounded-card design.
5. Typography choices and reasoning; candidate palette with accessible contrast; never assume previous lavender swatches were approved.
6. Propose exact original visual assets **but create none**; explain why each is necessary and legal/ethical source.
7. Distinguish which of the 16 shortlisted ideas would fit naturally; identify overlaps/possible merges without changing their status.
8. Show state model, sound opt-in and accessibility behaviour.
9. Top five creative/technical risks and how one prototype could verify the idea.
10. Record what remains OPEN and request my approval of the design sheet.

Do NOT invent personal text or treat research quotes as publishable. Stop after the blueprint.
