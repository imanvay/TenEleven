# STAGE 3 — IMPLEMENT ONE SPECIFIC APPROVED EXPERIENCE

Read `AGENTS.md`, relevant docs and decision log first.

Experience ID/name: [SX## OR SIGNATURE SCENE ID]
Explicit owner-approved design brief: [PASTE]
Owner-approved on-site text IDs: [C### or NONE]
Owner-approved asset IDs: [A### or NONE]
Files allowed to modify: [PATHS]
Features/files NOT to change: [PATHS]

Step 1: State the source-grounded emotional role, unique interaction and its difference from other scenes (no card/modal repetition). Show a brief before/after plan and targeted file list. Confirm source, scene and asset approvals.
Step 2: Implement ONLY that experience, preserving the approved overall visual identity and all unrelated working features. Use custom CSS/SVG/typography and purposeful motion only within approved design. No new external images or fake personal copy.
Step 3: Test 320/390/430px mobile, desktop, focus, touch, back/close, skip, reduced motion, muted sound, no missing assets and production build.
Step 4: Show screenshot/recording evidence if possible, tradeoffs, bugs, and concise approval request for the next batch. Update documentation **after** owner signs off.

Never mark surprise 'complete' purely to bump the progress count. Do not gate final content.
