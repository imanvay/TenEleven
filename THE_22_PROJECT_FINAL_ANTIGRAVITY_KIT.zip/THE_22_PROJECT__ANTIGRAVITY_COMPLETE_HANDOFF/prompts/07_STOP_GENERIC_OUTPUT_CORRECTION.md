# CORRECTION PROMPT IF GEMINI PRODUCES GENERIC BIRTHDAY UI

STOP. The output violates our source-of-truth creative constraints. Do not continue adding features.

Re-read `AGENTS.md`, `docs/03_NON_GENERIC_ART_DIRECTION.md`, `docs/13_CLICKIT_ZOYA_REFERENCE_REVIEW.md` and `docs/16_CREATIVE_QUALITY_RUBRIC.md`.

Identify exact visual/content anti-patterns in your current work, with file names and concrete examples: cakes/balloons/random generated photos, repetitive centered cards, identical modals, pastel gradients everywhere, overuse of 22/doodles/DM/floating objects, fabricated messages, decorative filler, or weak mobile hierarchy. Do NOT merely rename those patterns.

Propose a corrective art-direction plan for the **smallest affected scope** that creates an actually original scene and distinct interaction grammar while preserving all unrelated approved features. List files, screenshots/expected before-after, responsive changes, motion and reduced-motion behaviour. Do NOT modify anything until I approve.
