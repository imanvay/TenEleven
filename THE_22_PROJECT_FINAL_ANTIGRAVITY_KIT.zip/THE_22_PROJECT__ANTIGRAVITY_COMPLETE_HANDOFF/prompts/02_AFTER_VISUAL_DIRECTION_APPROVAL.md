# STAGE 2 — BUILD THE FOUNDATION ONLY AFTER VISUAL DIRECTION APPROVAL

Read full creative docs and decision log. The owner has explicitly approved this exact art direction: [INSERT OWNER APPROVAL].

**Scope:** Scaffold the minimal project foundation in React + TypeScript, with custom accessible layout primitives, site theme/motion system, audio-off default, intro/skip shell and free-exploration/navigation infrastructure. Do NOT build all 22 experiences or add placeholder stock imagery.

Before coding, list exact files to be added/changed and any deps; explain how the architecture supports truly different art-directed scenes. The existing approved assets list is [APPROVED_ASSET_IDS or NONE]. If no assets, use disciplined typography/CSS/SVG per the approved concept — no generated images.

Include:
- Readable responsive shell for 320–1440px; safe area, dynamic viewport support.
- Semantic controls, focus management and route/overlay exit; reduced motion.
- Local-only state, no account/no mandatory completion.
- Strict content whitelist; not a single unapproved quote in production.
- Explicit `CONTENT_PENDING_APPROVAL` labels in developer-only previews, never in final public build.
- Minimal smoke tests and instructions to view on iPhone/Android.

After coding, report exact changed files, build/typecheck result, screenshots (if tools allow), unresolved issues, asset audit, next owner approval. Commit/suggest a Git checkpoint. Do not implement signature scenes without separate approval.
