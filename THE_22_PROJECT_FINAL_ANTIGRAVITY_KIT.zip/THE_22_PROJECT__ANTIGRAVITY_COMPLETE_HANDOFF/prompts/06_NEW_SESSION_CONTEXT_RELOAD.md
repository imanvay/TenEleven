# SHORT PROMPT FOR EVERY LATER ANTIGRAVITY SESSION

Before any modification, read `AGENTS.md`, `docs/00_STATUS_AND_SOURCE_OF_TRUTH.md`, `docs/17_DECISION_LOG_AND_OPEN_ITEMS.md`, and all project docs relevant to this task. State LOCKED vs OPEN choices and exact files you plan to touch. Prioritize premium original non-generic art direction; do not generate or insert image assets autonomously; never invent private moments. Remember The 22 Project is one feature of a larger website, NOT the whole theme. Respect recipient's wish not to receive an ordinary birthday website, and preserve free exploration and optional ending. Use approved quotes/assets only; do not change unrelated existing features. Ask for approval before introducing a new scene, asset, layout direction or risky refactor.

TODAY'S TASK: [TYPE TASK]
FILES NOT TO CHANGE: [TYPE PATHS]
EXPECTED RESULT: [TYPE ACCEPTANCE TESTS]
