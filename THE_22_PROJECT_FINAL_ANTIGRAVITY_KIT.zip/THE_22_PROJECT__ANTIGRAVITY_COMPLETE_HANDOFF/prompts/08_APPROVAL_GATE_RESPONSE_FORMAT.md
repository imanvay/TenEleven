# REUSABLE REQUIREMENT FOR SPECIFIC IMPLEMENTATION REVIEW

Use this format in your answer before implementing any major scene. This is not an invitation to create assets or code by default:

- **Scene title / status:** LOCKED / SHORTLISTED / PROPOSED / OPEN
- **Narrative role:** What it makes her notice or feel, without predicting her reaction
- **Exact personal grounding:** verified message or creator-authored approved thought; source ID
- **Interaction choreography:** action → feedback → transformation → readable content → exit / replay
- **Originality rationale:** what makes this unlike generic websites and ClickIt Zoya
- **Art direction:** composition, typography, palette state, sound use (optional), asset list
- **Mobile and accessible fallback:** 320px, no hover, reduced motion, sound off
- **Privacy / publication status:** are the words/assets explicitly approved?
- **Files and dependencies to change:** precise
- **What you will NOT alter:** precise
- **Approval request:** one decision, with clear tradeoffs

STOP until approved.
