# STAGE 4 — HONEST DESIGN QA AUDIT OF THE CURRENT BUILD

Before modifying code, read `AGENTS.md`, all creative/QA documents and the approved decision log. Review the actual running website in both narrow mobile and desktop viewports. Do not give generic compliments.

**Audit categories**:
1. Originality: any cake/balloon/stock/AI image, repetitive pastels/cards, floating-object cliché, 22 fixation, copied Zoya structure?
2. Personal truth: every content item precisely source-grounded and `PUBLICATION_APPROVED`? Any invented favourite/quote or third-party info?
3. Interaction: does each scene feel meaningfully different? Does it respond interestingly beyond modal-open?
4. Art direction: hierarchy, composition, typographic craft, light/dark shifts, transitions, purposeful detail.
5. Mobile: 320/390/430px, real-device feedback, dynamic safe area, touch targets, performance.
6. Accessibility: motion reduction, keyboard/back, contrast, optional audio and skip.
7. Privacy/source: no raw Instagram export/secret/unsupported public password.

Give a **0–100 rubric score** using `docs/16_CREATIVE_QUALITY_RUBRIC.md`, clear evidence, exact failures, and a prioritized fix list. Be strict; if a hard-fail is present, say FAIL. **Do not automatically redesign**; ask for approval to fix specified components.
