# STAGE 5 — FINAL RELEASE QUALITY AND PRIVACY REVIEW

Run this only after owner-approved concept, assets and on-site copy. Read `AGENTS.md`, docs 12/14/15/16/18 and current decision log. Do NOT deploy/share before explicit owner approval.

Run production build/typecheck/lint; inspect `public/`, `dist/`, network-loaded media, Git changes and source maps for unwanted Instagram archives or third-party private details. Audit quote registry (only PUBLICATION_APPROVED allowed). Check audio rights, respectful treatment of Bappa/donation, age/date 22 / Nov 10 2026, opt-in sound, motion reduction, the opening's option to decline and independently accessible finale. Test actual iPhone Safari/Android if possible, otherwise state testing limitations explicitly and request owner to test.

Produce:
1. Detailed PASS/FAIL table for every category in `docs/15_QA_TESTING_AND_LAUNCH.md`.
2. Concrete evidence/commands and screenshots, not invented scores.
3. Critical bugs and recommended fixes, ordered.
4. Media/privacy risk report.
5. Git rollback reference and Vercel access/protection plan.
6. One final 'go/no-go' recommendation, with OWNER SIGNOFF REQUIRED.

Do not claim deployed until tools actually deployed and verified it.
