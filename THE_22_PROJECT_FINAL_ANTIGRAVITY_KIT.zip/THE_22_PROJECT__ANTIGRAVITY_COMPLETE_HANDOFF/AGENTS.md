# AGENTS.md — STRICT NON-GENERIC CREATIVE + DEVELOPMENT CONTRACT

Read `README_FIRST.md` and `docs/00_STATUS_AND_SOURCE_OF_TRUTH.md` **before anything else**, then all `docs/*.md` before taking initiative. The docs contain extensive user-approved history. You are responsible for preserving it.

## 0 — Precedence and decision states
1. Latest **explicit owner approval** in this project, recorded in `docs/17_DECISION_LOG_AND_OPEN_ITEMS.md`.
2. **LOCKED** rules in `docs/00_STATUS_AND_SOURCE_OF_TRUTH.md` and this file.
3. Approved specs and content in docs and manifests.
4. Proposals labelled **SHORTLISTED / OPEN / EXAMPLE** are *not* permission to implement or publish.
5. Ordinary AI taste, default themes and assumptions have **zero authority**.
If documents disagree, report the contradiction and stop; never silently reconcile.

## 1 — Creative north star
Build a unique, premium, mobile-first interactive **birthday experience for Pariii/Buddhuuu**, playful at first and increasingly thoughtful where appropriate. A subset of exactly 22 personal discoveries is a component; it must **not** dictate the overall layout, headings, sitemap, progression, animation motif or visual theme. The entire experience cannot be reduced to “22 things,” “22 gifts,” “22 cards,” “22 rooms,” or “22 balloons.”

## 2 — ZERO-GENERIC rule (hard-fail conditions)
DO NOT:
- Generate/download/insert **any** photograph, AI image, illustration, icon pack, sticker, background or stock asset on your own, including through integrated image generation. Ask for item-specific approval first.
- Insert cakes, candles, balloons, gift boxes, confetti wallpaper, bows everywhere, random temples/mountains/landscapes, Kedarnath imagery, generic girl/avatar/photo, silhouette impersonating her, emojis everywhere, or generic birthday clipart.
- Generate decorative filler solely because a section seems empty. Deliberate whitespace is preferable to invented ornament.
- Reuse a repetitive “pastel gradient → center heading → white rounded card → purple button” template; 22 numbered cards; chapter-based scroll; 22 identical envelopes; endless compliments; quiz loops; clichéd certificates/badges.
- Convert the entire website into doodle art, animated chat bubbles, floating-object map, OS simulation, stars/collectibles or the number 22. **No singular repeated gimmick.**
- Fabricate dialogue, recipient likeness/voice, call history, shared photos, private favourites, spiritual statements, sensitive life events, quotes or mutual romance. Don't infer content beyond the reviewed source.
- Make the user wait through forced intros, timed gates or challenges to access important messages. No scroll-jacking, motion overload or autoplay sound.
- Present speculation as fact: “she will cry,” “she will love it,” “this is her favourite song,” “we met in person.”

## 3 — Art-direction authorization
Code-based visuals (CSS/SVG/Canvas/procedural graphics) are allowed **only under an approved scene direction**. *No image generation* does not mean boring text-only design; craft intentional visual composition, movement and editorial typography. For any new visual asset, propose: function, originality rationale, source method, content accuracy, cost/performance, fallback, privacy, and ask owner before creation. Maintain `docs/18_CONTENT_AND_ASSET_REGISTERS.md`.

## 4 — Respect her boundaries
The recipient has explicitly expressed that she did **not** want another birthday website of the sort previously made. Do not pressure her or frame her refusal as a challenge to win. The experience, if shared, should straightforwardly acknowledge the preference and offer an obvious graceful exit/skip. No obligation to spend 10 minutes, finish every item, respond, or reciprocate. Keep the entire treatment friendship-oriented.

## 5 — Source fidelity
- Source of personalization: curated creator-provided notes and original social messages, **never made-up screenshots**.
- Only use quotes/claims marked `PUBLICATION_APPROVED` in the content register in the actual website.
- No complete chat export, raw ZIP, sensitive screenshots or unrelated third-party content in `public/`, bundle, commit, backend logs or repo.
- Avoid lyrics, copied artwork, downloaded commercial tracks, account credentials and private gift shipping details in source.
- If uncertain, insert `CONTENT_PENDING_APPROVAL` in local docs or a non-public wireframe; don't fill with invented content.

## 6 — Correct relationship & media model
- Friend, not established romantic partner. No invented couple imagery or love confession.
- Creator may record their **own voice** for a separate avatar-led birthday film (not yet scripted). Never clone/generated recipient voice or face; do not infer the film must be embedded.
- Letter, physical gift, film and website have complementary jobs; do not paste the full letter into the site or duplicate the film's plot.
- No recipient photos, recipient voice notes or voice/video calls are available.

## 7 — Engineering constraints
- Mobile-first, works on small Android and iPhone Safari, desktop polished too; no hover-only actions.
- Accessible buttons, readable text and contrast; reduced motion, keyboard traversal, close/back affordances, no mandatory dragging, audio always user-initiated.
- Lightweight art direction first; don't casually use heavy 3D/particle engines just to look impressive.
- Preserve working features and state; don't overwrite unrelated files. Use Git with reviewed diffs and descriptive commits. Use data-driven content and component boundaries, not a giant App.tsx.
- Avoid exposed passwords, raw private logs, unprotected public URLs with private conversations. A client-side numeric login code **is not security**.

## 8 — Your response contract EVERY milestone
Before touching code:
1. **Read relevant files**, state what is LOCKED vs OPEN and requested scope.
2. Show **one clear concept or implementation plan** with unique purpose, visual logic, gestures, emotional role, exact files, tradeoffs and privacy implications.
3. Explain how it differs from ClickIt Zoya's repetition and generic AI website output.
4. Ask owner to approve. If owner has already explicitly approved the exact task, proceed with that task only.
After coding:
5. Show file changes, demo path, browser/mobile evidence, failures/limitations, no-image compliance, QA results and commit instructions.
6. Update decision log and registers when content/design is approved.

## 9 — First turn requirement
First response to `prompts/00_FIRST_MESSAGE_TO_ANTIGRAVITY.md` must be an audit + **three radically different site-wide creative directions**. **DO NOT write code, install dependencies, generate graphics or take browser actions before owner approval.**

## 10 — Never quietly change a decision
When the owner says “don't put that,” record its rejection. Do not reintroduce the same rejected concept under a different name. In particular: **Kedarnath postcard removed, Rasmalai interaction removed, doodle-only site rejected, 22-dominated layout rejected, floating-object/card-grid default rejected.**
