# 07 — THE 22 DISCOVERIES: COUNT IS A SUBSYSTEM, NOT THE WEBSITE

## Real status
- Project working title: **The 22 Project** because she turns 22 on Nov 10, 2026.
- **16 previously chosen ideas remain SHORTLISTED**, not final copy/layout. See `06_SIXTEEN_EXPERIENCE_SPECS.md`.
- **6 additional discovery ideas are NOT LOCKED**. Do not pad the count with fabricated songs, fake childhood memories or 6 clones of the same joke.
- The creator explicitly said: **“sirf 22 se enough nahi hogi website.”** Site architecture must include larger original experiences and crafted signature moments.

## Territory audit — risk of duplication
| Cluster | Ideas at risk of sameness | Decision needed |
|---|---|---|
| Origin | First DM + Random? Right + editing/fan-page origin | Differentiate by interaction or merge |
| Language | Nickname history + cute-typing dictionary | One timeline vs one lexicon, or merge |
| Memory | Badam challenge + 'things I remember' | Avoid creating two trivia games |
| Emotion | Things I notice + friendship advice + keepsake + finale | Give each a distinct job, avoid repeated letters |
| Work | Pariii.exe + workday appreciation | One playful / one genuinely appreciative |
| Other gifts | Bappa + helping someone + physical gift/letter | No duplication or false claims |

## Six research leads, all PROPOSED not selected
1. **Birthday morning**: she often checks midnight wishes in the morning — humorous gentle sunrise composition. Not a timer she must obey.
2. **1 August: 'haan dost hogye'**: small meaningful friendship milestone; avoid declaring romantic date anniversary.
3. **People make a place special**: Aug 14 line about people, not location. Avoid the explicitly rejected Kedarnath postcard and random scenic image.
4. **Editing/fan-page beginnings**: connected via edits. May already overlap with First DM — must distinguish meaningfully.
5. **Cultural/language playful exchange**: only direct verified mutual exchanges; avoid stereotypes or fake phrases.
6. **Garba/conversation humour**: only if creator supplies a specific mutually funny actual moment.

These six are a *research shortlist*, **NOT six approved final slots**. Before selection score each on: (1) specificity to Pariii, (2) source clarity, (3) original interaction potential, (4) distinctiveness from existing 16, (5) respectful tone, (6) visual quality and mobile feasibility.

## Anti-count obsession
Never design:
- 22 numbered buttons/tabs/cards/envelopes as the homepage.
- 22 stages she must beat, or '100% complete to unlock final message'.
- Big '22' typography repeated in every area.
- A hidden collectible as the only way to find important content.

Allowed: occasional count acknowledgement; optional progress tracking; a well-defined personal collection in one non-dominant part of the site; customized numeric motif in a *single* approved signature moment if it truly earns its place.

## How progress should work (technical intention, not UI locked)
- Mark as 'seen' only when a meaningful experience has been explored; no punishment or congratulations spam for every tap.
- All previously opened items can be revisited.
- Hints optional. Finale available without 22/22.
- If a shortlisted idea merges with another, discuss whether count must still equal 22 before adding filler. A meaningful 18 is better than fabricated 22 unless owner says count is mandatory.

## Owner decision record for adding a discovery
```text
ID:
Title/working name:
Real verified source and date:
What this says about HER or THEIR friendship:
Why this is DIFFERENT from existing ideas:
Type of interaction (more than generic reveal):
Proposed visual direction (no stock images):
Personal text needing approval:
Assets needing approval:
Status: PROPOSED -> SHORTLISTED -> APPROVED -> BUILT -> QA_PASS
```
