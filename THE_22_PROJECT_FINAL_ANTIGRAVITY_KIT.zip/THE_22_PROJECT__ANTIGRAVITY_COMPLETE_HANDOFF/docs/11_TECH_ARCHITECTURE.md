# 11 — RECOMMENDED FRONTEND ARCHITECTURE / IMPLEMENTATION PRACTICES

> **Technical recommendation, not permission to scaffold until chosen concept and design approval.** Owner prefers Google Antigravity + Gemini Flash. React + TypeScript + Tailwind/custom CSS + selective Motion/GSAP + Vercel is the initial direction.

## Base stack (recommended)
- **React + TypeScript + Vite** for a responsive frontend with typed interaction interfaces; modern React framework alternatives may be proposed with reasons, but avoid needless backend complexity.
- **Tailwind CSS** for foundations plus **bespoke CSS** for authored compositions, responsive art and advanced choreography.
- **Motion** for simple React transitions OR **GSAP** for substantial choreography where justified. Don't import both everywhere. No giant WebGL engine unless an approved scene proves necessary.
- **SVG, accessible HTML and scoped Canvas** as needed. Image assets only after explicit approval.
- **Vercel** target for preview/final hosting, with appropriate privacy/protection. **Static passcode typed in React is not authentication**.
- Git with working checkpoints and intentional commits; avoid autonomous sweeping file rewrites.

## Proposed modular folder map (adapt to final concept)
```text
project-root/
  AGENTS.md
  docs/                   # creative source of truth; reviewed, not blindly dumped in UI
  prompts/                # agent stages (not shipped to browser)
  public/                 # ONLY approved, sanitized, rights-cleared assets
  src/
    app/                  # layout, navigation shell, motion/audio preferences
    design/               # tokens, typography, reduced-motion CSS, scene primitives
    scenes/               # site-wide signature scenes distinct from discoveries
    experiences/          # personal interactions by stable id
    content/approved/     # only user-publication-approved small pieces
    components/           # accessible generic UI primitives, not template whole pages
    hooks/                # state, viewport, focus, user preferences
    lib/                  # small utilities, no raw chat parsers in prod bundle
    styles/
  tests/                  # UI, accessibility, interaction acceptance checks
```
The folder map is a recommendation. Actual file names must follow chosen concept; don't mindlessly generate dozens of empty folders.

## Explicit separation of data from visuals
Use a content manifest (example schema, **NOT actual publishable content**):
```ts
type Approval = 'OPEN' | 'OWNER_REVIEWED' | 'PUBLICATION_APPROVED';
type Moment = {
  id: string;
  kind: 'playful' | 'reflective' | 'signature' | 'keepsake';
  title: string;
  sceneId: string;
  approval: Approval;
  sourceEvidenceId?: string;    // e.g. E01, only metadata
  approvedCopy?: string;        // present ONLY if publication approved
  optional: true;
  assetIds: string[];           // all assets separately approved
};
```
Do **not** ship research drafts or source-sensitive notes in production JSON. Use a build-time whitelist: only `PUBLICATION_APPROVED` content compiles into the site. Maintain exact source IDs in private planning documents, not as links to raw chat exports.

## State design
- Persistent progress in `localStorage` scoped to this site/device; do not require login and do not promise cross-device synchronization.
- State examples: `viewed`, `soundOptIn`, `reducedMotionOverride`, `introChoice` where appropriate.
- 'Final' not derived from `viewedCount === 22`.
- Do not collect analytics, identities or precise visit timing unless separately approved (privacy by default).
- Avoid exposing gift passcodes, private notes and secrets in frontend code. Keep sensitive assets behind actual access controls (see privacy doc).

## UX engineering essentials
- Build scenes as isolated modules with stable entry/exit semantics and preserved scroll/focus state.
- Scene transitions should be independently testable and not mutate global styles unpredictably.
- Interactive overlays: trap focus, Escape closes, return focus to trigger; no inaccessible fake div buttons.
- Fonts load safely with fallback; prefer CSS/SVG visuals to heavyweight autoplay video.
- All audio must begin with user gesture and have visible pause/mute; recover gracefully from blocked autoplay.
- Event handlers cleaned up and requestAnimationFrame/GSAP animation contexts disposed on unmount.
- Animate `transform`/`opacity` preferentially; avoid huge animated box-shadow/filter/backdrop-filter layers on mobile.
- Lazy-load heavy experiences, keep critical first paint fast, reserve space to prevent layout shifts.

## Security and privacy
- Don't commit original Instagram ZIP, screenshots with other users, addresses, raw recording, gift shipping labels or any private `1234` reference password into this new project's public files.
- If share should be private, prefer Vercel deployment protection/access-gate mechanisms, not a fake 4-digit React form.
- Consider a site with **few approved quotes only**, with no raw private source included in repo at all.
- Use environment variables for non-public configuration but remember `VITE_*` becomes client-visible. No secrets in bundle.
- Escape dynamic content and prevent unsafe HTML injection; strict content maps, no eval.

## Engineering quality targets (evaluate, do not promise blindly)
- No critical interaction lag on real mid-tier phone. Profile any heavy animation.
- Core text visible without JavaScript-intensive effects. Reduced-motion works.
- Reasonable LCP/CLS/INP results for mobile; measure with Lighthouse and actual phone where possible, do not invent scores.
- Modern browser compatibility: iOS Safari, Chrome Android, desktop Chrome/Edge.
- README with dev/test/deploy commands, no console errors, no missing import/asset errors.

## Agent task discipline
Do not implement the whole site in one prompt. Each milestone must specify exact files touched, expected interactive behaviour, evidence sources, acceptance tests and rollback step. After coding, show before/after screenshot or short recording and await owner review. Explicitly list any use of external assets (should be NONE unless approved).
