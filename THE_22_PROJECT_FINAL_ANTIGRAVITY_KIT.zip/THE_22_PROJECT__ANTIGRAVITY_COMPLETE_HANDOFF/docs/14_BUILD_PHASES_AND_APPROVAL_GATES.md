# 14 — BUILD ROADMAP: STAGE GATES AND TANGIBLE DELIVERABLES

## The number-one working rule
**Do not ask Gemini Flash to “build everything” in one mega prompt.** A massive brief is for persistent context, not one-pass autonomous implementation. First settle a distinctive concept; then approve design; then code short well-reviewed milestones. A rushed fully populated template is an unacceptable outcome even if technically functional.

## M0 — Context loading & contradiction audit (NO CODING)
**Input:** full handoff folder.
**Agent deliverables:** (a) concise understanding of LOCKED/SHORTLISTED/OPEN/REJECTED; (b) verify key personal facts; (c) list user preference not to receive website; (d) top anti-generic rules; (e) contradictions or missing sources.
**Owner gate:** confirm interpretation. **No** package installation, photos, code or generic template.

## M1 — Three distinct overarching concepts (NO CODING)
**Agent:** propose truly different worlds/navigation identities, each with two signature experiences **outside** 22, a first impression, emotional pacing, mobile implementation, risk/tradeoffs, differentiation from ClickIt Zoya.
**Proof of quality:** concepts are structurally different, not variations of same floating-object UI.
**Owner gate:** select/combine concept and record choice. Do not lock palette or micro-scenes without review.

## M2 — High-fidelity creative direction (NO CODING unless wireframe explicitly requested)
**Agent:** art direction sheet: typography, colors, compositional language, motion storytelling, mobile hero, exploration grammar, scene samples, responsive design, asset proposals and interaction maps. Give purposeful original alternatives where owner doesn't want AI imagery.
**Owner gate:** approve specific scene/design/asset directions. Update decision log.

## M3 — Functional technical skeleton
**Agent:** minimal React TS app, design foundations, semantic navigation, scene transition infra, reduced motion, audio off, graceful back/close, local progress, code organization. Use text placeholders labelled clearly, NOT generic filler art.
**Proof:** project builds, minimal a11y interactions, 320–430 px widths, no autonomous generated images.
**Owner gate:** review shell demo and code diff.

## M4 — First exceptional flagship scene
**Agent:** build a SINGLE approved signature experience to production-level craft. Include motion, fallback, responsive composition and any source approval. Do NOT bulk-build 22 features.
**Proof:** screenshots/video of iPhone-sized view; motion reduced check; performance and readability; demonstrate visual distinction from Zoya.
**Owner gate:** accept or iterate until truly strong.

## M5 — Discovery interactions in thoughtful batches
**Agent:** each batch 2–4 approved features at most, each differentiated and sourced. Check collisions (origin vs Random, dictionary vs nicknames, etc.).
**Proof:** feature acceptance matrix and no invented personal copy; tap/keyboard/motion tests.
**Owner gate:** merge/modify/drop. Six remaining slots stay OPEN until separately approved.

## M6 — Other flagship moments and optional connections to gifts
**Agent:** build additional owner-approved major scenes; link video/letter/gift ONLY when real assets exist and owner approves. Do not clone separate video or letter.
**Proof:** at least one carefully composed interactive experience beyond the 22 subsystem. Full-screen beats have narrative and functional purpose.
**Owner gate:** creative review.

## M7 — Full content, privacy and visual QA
**Agent:** publish ONLY `PUBLICATION_APPROVED` quotes; content/cultural sensitivity audit; font/audio/media rights; Vercel preview protection; reduced motion, audio off, all target devices, no secret leaks, performance. Owner signs off on all final copy.
**Proof:** completed QA checklist with evidence, known defects, screenshots and build output.
**Owner gate:** explicit permission to deploy/share link.

## M8 — Deploy and maintain
**Agent:** deploy under approved access, check from real external phone, monitor critical errors, prepare graceful backup (static message or accessible fallback), make final Git tag.
**Owner gate:** ready to send. Website remains optional for recipient.

## Always-on milestone format
```text
GOAL:
APPROVAL STATE:
FILES TO CHANGE (precise):
FILES NOT TO TOUCH:
SOURCE/QUOTE REFERENCE IDs:
NEW VISUAL ASSETS (owner-approved yes/no):
VISUAL + INTERACTION THESIS:
WHAT THIS IS NOT (anti-generic comparison):
MOBILE/ACCESSIBILITY TESTS:
PREVIEW RESULT:
ROLLBACK/GIT COMMIT:
OPEN RISKS/DECISIONS:
```

## Owner-facing change-control rule
If the owner says “bas ye change karo” or “do not change other UI,” obey literally. No broad restyling, package swaps, deleted animations or architecture rewrite. If a refactor is indispensable, explain exact reasons and request permission first.

## Scheduling note
Target date Nov 10 2026. Quality risk increases if the whole project begins too late. Prefer one excellent opening + a few excellent signature experiences + truthful personal moments over a broken collection of forced 22 features. Clearly distinguish design ambitions from schedule reality.
