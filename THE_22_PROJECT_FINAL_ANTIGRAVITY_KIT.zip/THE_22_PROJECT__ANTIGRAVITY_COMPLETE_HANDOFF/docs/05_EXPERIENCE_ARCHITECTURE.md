# 05 — EXPERIENCE ARCHITECTURE: WEBSITE BIGGER THAN THE 22 SUB-FEATURE

## Three levels, not three visible chapters
**Level 1 — Site-wide creative identity (OPEN):** unified visual language, opening impression, navigation grammar, sound/motion rules, original personality.
**Level 2 — Flagship experiences OUTSIDE the 22 discoveries (OPEN):** large memorable, art-directed interactions/visual scenes that make the site ambitious independently of the discovery count.
**Level 3 — Personal discovery system ('The 22 Project'):** 16 shortlisted personal territories plus 6 not yet approved, transformed into varied interactions without 22 uniform buttons/cards.

Do not force visitors through visible Levels 1/2/3. These are production planning abstractions.

## Curated opening → genuine freedom (LOCKED high-level)
- Opening should feel intentional, short and accessible, with sincere acknowledgement of the recipient's preference not to receive this sort of website. **Opening copy OPEN**. No guilt, no pressure.
- User can continue, skip an animation or exit. It should not be a 40-second forced movie.
- After opening, free choice: discover, revisit, skip, change sound preferences, reach final message with no collection challenge.
- Let navigation suit the **selected site-wide concept**. Do not inherit previous assistant's upper/middle/lower canvas or phone/floating-object map by default.
- The 22 set may be discovered through different mechanisms: an affordance within a signature scene, an optional area, direct navigation, contextual Easter eggs — but never solely inaccessible hidden pixel hunts.

## Five distinct interaction families to mix thoughtfully
1. **Performative scene:** full-screen original transformation/reveal with intentional choreography and optional user input.
2. **Playable mini-interaction:** silly but related to real humour (e.g. Badam); accessible skip and no repeated quiz forms.
3. **Useful/curious digital artifact:** e.g. a genuinely custom Pariii.exe or dictionary, built as a functional small experience rather than fake decoration.
4. **Reflective piece:** real insight, appropriately quiet presentation; reads well without animation.
5. **Lasting keepsake:** download/print/saveable authored piece, licensed/owned artwork, optionally personalized; not an achievement certificate.

## Avoid overlapping every theme
Potential collisions to design around:
- First DM vs `Random? right` vs origin/editing-fan-page concept.
- Badam memory game vs 'things you remember' and other memory quiz ideas.
- Nicknames vs Typing Dictionary.
- Friendship Advice vs Things You Notice vs final letter.
- Pariii.exe vs Workday Appreciation.
- Radio vs creator's separate birthday video.
Each must either have a distinct role/interaction **or be merged** with approval; do not inflate count artificially.

## Consent and respectful experience
The site can be enjoyed even if she only explores for 30 seconds. Never say 'I worked so hard, please finish'. No surprise audio that she didn't request. No forced timer or publicly visible visit tracking. If she elects not to open, that choice is respected.

## Recommended state model (architecture, not chosen UI)
- `introAcknowledged: boolean` (local only)
- `seenDiscoveryIds: Set<string>` (only record when substantive interaction completes or owner-approved semantics)
- `experienceResumeState` where appropriate; do not force users to 'complete' a memory.
- `audioEnabled` defaults false; persist preference only after opt-in.
- `reducedMotion` respect OS, plus optional app toggle.
- `journeyMode`/theme derived from **scene design**, not arbitrary global toggling.
- `finalAvailable = true` independently of seen count.
- No personal analytics/telemetry by default. User does not need an account.

## Reasonable navigation behaviours
- Obvious ways to open an experience, close it, and return to previous point without losing scroll/focus.
- Discreet access to discoveries and previously seen experiences, rather than 22 cluttered visible buttons.
- In any mode, avoid a dead end; no hidden-only exit.
- Keyboard Escape closes modal; focus is trapped in modal, then returned to trigger; Back button/hardware navigation works sensibly.
- Avoid infinite-scroll performance pitfalls and mandatory drag gestures; provide tap alternative.
- Surprises are optional delights, not required tasks or collect-a-thons.

## Site-wide moments should justify themselves
Owner wants **multiple signature moments** beyond the 22. Number and concrete design are OPEN. An accepted flagship scene should demonstrate a level of art direction/interaction the previous site lacked. Example possibilities (not approvals): a bespoke opening visual performance, an original 'digital toy' using their editing/engineering identity, a resonant finale with personal callback; beware collapsing again into the same motif.
