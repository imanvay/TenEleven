# 02 — REAL PERSONAL CONTEXT / RESEARCH ANCHORS / DO-NOT-INVENT RULES

> **PRIVATE RESEARCH REFERENCE, NOT PUBLICATION APPROVAL.** Do not paste any of these lines into the live site without the creator's item-by-item review. Do not ask for complete Instagram archive in Antigravity. No third-party details. Dates are from creator-provided message exports or explicit statements; if a scene depends on exact timing, confirm timezone and text in original export.

## Identity and relationship
- Recipient name/nicknames: **Pari**, **Pariii**, **Pariiuuu**, frequently **Buddhuuu** (owner's affectionate spelling varies). Turning **22** on **10 November 2026**; **birth year 2004**.
- Creator (her friend) nicknames: **Bhonduu**, **bhonduui ram ✨** (set by her), **Golu moluuu** (set by her). Playful “kaun jyada pagal hai?” banter.
- Met/reconnected in Instagram chats; shared interest/background in editing/fan pages. **Online friendship; no user-provided photos of Pariii, no voice notes/calls**.
- Friendship is not established as a romantic partnership. Do not invent couple themes, intimate statements, holding hands/kissing images, inferred physical encounters or declarations.
- The owner is investing care and time in multiple birthday surprises; don't make the website guilt her about this effort.

## Historical anchors and verifiable message candidates
**E01 — First DM, 28 July 2026**
- Creator at approximately 04:13 (as displayed in export): `Hey, why did you stop uploading edits?`
- Her response around 04:44: `I'm working now so don't have time`.
- Creator asks: `Did you recognize me?`
- She replies: `Random? right`
- Creator: `Nope😭 ikdevv`
- Her reply: `Ohh how are you`.
- Verified against earliest old-account exported messages; first visual/editorial moment candidate, not required main theme.

**E02 — Explicit friendship, 1 August 2026**
- A line in the old Instagram thread: `Thanks yaar mature nahi hun vese but haan dost hogye hai hum` (historically quoted in earlier review). Confirm exact original before publication.
- The line communicates a real friendship milestone; don't turn it into an invented romantic anniversary.

**E03 — Nickname chronology (Aug 2026)**
- 1 Aug: creator sets her IG nickname with stylized `Buddh(h)huuuu✨` form. 17 Aug: fairy variant.
- 4 Aug 09:22: she sets creator's nickname to `bhonduui ram ✨` (export text).
- 13 Aug 10:39: she sets creator's nickname to `Golu moluuu` (export text).
- The exact *historical* nickname strings may include spelling/styling differences; verify the original once during content approval. Don't invent extra nickname milestones.

**E04 — Typing style, 5 Aug 2026**
- Her `Pin pe dekhtu` (8:22 as displayed).
- Creator responds `Ye aap dekhtu, kartu, pakkuu Ye sab jaanbuj ke likhte ho yaa by mistake hota😂` (8:23 as displayed).
- This provides real quirky spelling material. `kartu` and `pakkuu` are quoted in creator's message, not automatically independently verified as words she herself typed in that specific excerpt. Mark individual entries accordingly.

**E05 — Friendship perspective, 6–14 Aug**
- 6 Aug 09:46 she wrote `Understanding pe hota dosti ke` (export text).
- Other real discussions about expectation management, healthy independence and not taking things personally. Use context-sensitive quotes, not over-interpretation.

**E06 — Badam jokes, 2 & 10 Aug**
- 2 Aug creator: `Jao yaar badam khao aap😔`.
- 10 Aug 08:27 she: `Koi na badam kahoo`.
- A real teasing motif; DO NOT build the whole site as almonds or turn it into a harsh memory test.

**E07 — Her job**
- She discussed being a **network engineer**, working with **network/security** concerns, including routers/switches, endpoint protection and firewalls. She is a working professional. Respect her competence and privacy; never claim a particular employer, team, salary or workplace access unless approved.

**E08 — Birthday boundary**
- 12 Aug she explicitly stated she did not want the same generic birthday website created for everyone, and repeated her objection more than once later. Do not frame that as playful resistance to be overcome. The best approach is optional sharing with honest acknowledgment, ideally confirm whether sending any website is welcome.
- She mentioned often viewing midnight birthday messages after waking in the morning. Birthday morning is a **proposed** discovery idea, not yet selected.

**E09 — People make places, 14 Aug 08:54**
- Her line: `I don't have a place  I have ppl who make the spot favourite` (double space reflected in export). A wonderful idea for meaningful visual metaphor but not a fixed feature. Preserve context; do not use random Kedarnath imagery.

**E10 — Her reactions to sweet gestures**
- Past reactions include `Ohh so sweet yaar 😭😭`, `Kitnaa Sweet gesture thaa yeh 🫠🫠🫠`, `Ohh soo sweet 🤍`, `Soo sweet of you 😭😭😭`, and appreciative comments on creative effort. Do not claim one exact phrase is her constant catchphrase.

**E11 — Her insightful observations**
- She described the creator as caring deeply for people and forgetting to think about himself (9 Oct). This is personal feedback, not proof of romance and not a line for generic scripted flattery.

**E12 — Music, work, culture, spiritual identity**
- Mentioned singers include **Jass Manak** and **Atif Aslam**, and likes South Korea in user's earlier description. **Do not claim a definitive favourite single song.** No copyrighted tracks or lyrics bundled in source without license.
- Conversations involve Gujarati, Kutchi, Marwadi, and Garba in various contexts; don't make assumptions about ethnicity or religion from this alone.
- The user describes her as cheerful, chill and often sleepy, with genuine care for people. Treat as **creator observation**, not an objective diagnosis or totalizing label.
- She has devotion/affection for **Bappa**; gifts under consideration include a small Ganpati Bappa murti. Treat visual representation respectfully and require approval for any devotional imagery.

**E13 — 18 Oct discussion about birthday and kindness**
- She said `Toh mere birthday ke din kise garib ko khana khilana` (as exported), asking the creator to feed someone in need on her birthday. Only claim it happened **after** the owner actually completes it; protect the helped person's privacy.
- She was receptive to a murti and handwritten letter. The creator has NOT confirmed those have been purchased/posted/completed.

## What user explicitly told us about her (not direct quotes)
- Appreciates genuine care, handmade touches, playful banter and emotional maturity.
- Likes joking “kaun jyada pagal hai?”
- Tends to be calm/cheerful, can be sleepy; works, therefore avoid infantilizing or portraying her only as 'pookie'.
- She doesn't want an ordinary friend birthday website like one created for everybody.

## Content integrity policy
- **FACT VERIFIED ≠ PUBLICATION_APPROVED.** All excerpts are research leads until the creator signs off on exact intended on-screen text, sender/date attribution and visibility.
- Several conversational fragments include sensitive third-party posts. Do **not** display private third-party content, mutual friends' details, contact IDs, full handles or social-media attachments without permission.
- No entire chat export in website repository, build pipeline, app/public folder or model prompt. Better: request *individual selected quotes* from creator during copy approval.
- Any new “Pariii says…” line must be cross-checked. Preserve typos/emojis verbatim when quoting, but draft narration separately and label it as original.
- Historical timestamps from exports may be display-local; do not assert timezone without check.
- Any link to video/gift/letter must be contingent on asset existing; avoid fake unlocks, fabricated future results or placeholder affection masquerading as fact.
