# 10 — COPYWRITING, TONE, NARRATIVE AND EMOTIONAL INTEGRITY

## Natural tone
- Creator speaks in genuine conversational **Hinglish**, sometimes English, often expressive spelling: `Pariiiuuu`, `Buddhuuu`, `Bhonduu`, `yaarrr`, light emoji use (`🥹🤍😂`). Preserve his real manner rather than artificially uniform 'AI cute' text.
- Recipient has distinct spelling habits and humour; never fake her words in quotations.
- Different scenes should have different *rhythms*: a funny micro-interaction can be silly, a work appreciation can be mature, a blessing calm, a final message sincere.
- Do not write one breathless overly sentimental paragraph after another; the creator disliked generic AI-sounding birthday messages in other requests.
- Don't infantilize her through 'pookie' clichés or only sleepy jokes; she is 22 and professionally works in networks/security.
- **Friendship-oriented**, not an implied romantic confession or digital love story. Avoid “forever mine”, fake relationship vows, guilt, possessiveness, or implying meetups/calls/photos.

## Respecting the recipient's objection
Recipient explicitly said she did not want a generic website like the other one. The creator still wants to offer a personal site. Opening should be honest and **optional**, not argumentative or emotionally coercive. Do not use lines like “I worked so hard, you HAVE to open everything,” “please don't disappoint me,” or “I broke your rules because I love you.”

**PROPOSED sample opening (NOT PUBLICATION_APPROVED, may need shortening):**
> Pariii, ek chhoti si baat pehle. Mujhe yaad hai tumne bola tha ki birthday par waisi website nahi chahiye. I heard you. Maine phir bhi kuch alag banane ki koshish ki, but tumhe ise open ya complete karne ki bilkul zaroorat nahi. Bas ek chhota creative gift hai — only if you feel like exploring. 🤍

This is a tone example. Owner must author/review actual intro. Recipient should have a clear way to decline.

## Emotional structure (not chapters)
- **First impression:** curiosity and genuine craft, not instructions or declarations.
- **Playful relief:** unexpected interactions with real nicknames/phrases and humour.
- **Human recognition:** her working life, thoughtful perspective, boundary awareness, kindness.
- **Quiet truth:** select concrete memories/observations and respect for her without exaggerated claims.
- **Payoff:** memorable author-written personal conclusion, not another generic 'best friend ever' certificate.

## Sample microcopy style cues — ORIGINAL NARRATION ONLY
These are examples of original lines one *could* draft; NOT direct quotes and NOT approved for use:
- `Okayyy... ye thoda unexpected hai 😭`
- `Aapko ye yaad hai ya badam bheju? 😂`
- `This one isn't a game. Just something I wanted to say.`
- `Take your time. Koi challenge complete nahi karna.`
- `Bas itna hi. Thank you for being you.`
The agent must label them as DRAFT and let creator adjust accent, punctuation, emojis and wording.

## Copy constraints
- Exact quoted lines must match verified exports, even spelling/emojis. Distinguish quote vs narration visually/semantically.
- Do not quote reels/posts from unrelated accounts just because they appear in export.
- No invented favourite song, birth location, address, exact employment/company, screenshot of her, or claim of calling/meeting.
- Avoid excessive personal disclosure: selected memories for a private site only; never complete conversations in public code.
- Keep bite-size text; the physical handwritten letter carries the longest emotional message.
- Respect recipients of any feeding/charity action: never display their identity or shame-inducing descriptors; say only true actions.
- No copyright lyrics or full passage reproductions from songs.

## Personal story and content review process
1. Creator chooses a moment / approves a premise.
2. Agent proposes **why it matters**, the exact short quote if needed, and how to display it.
3. Creator approves the quote / spelling / sender attribution / public-vs-private visibility.
4. Only approved copy is moved to `src/content/approved/*` and registered in `docs/18_CONTENT_AND_ASSET_REGISTERS.md`.
5. Audit final app for accidental placeholders and invented dialogue.

## “If changed the name” test
For every reflective scene, ask: *Would this line be true for dozens of other people?* If yes, replace with a specific creator-approved observation or delete the scene. Truth, restraint and specificity matter more than word count.
