# 17 — LIVING DECISION LOG (UPDATE AFTER EACH APPROVAL)

**As of 20 Oct 2026: Creative brief complete; overarching concept NOT selected; implementation NOT started.**

## Locked decisions, with provenance from discussion
| Decision ID | Date known | Topic | Owner decision | Status |
|---|---|---|---|---|
| D001 | Oct 2026 | Site purpose | Extraordinary personal birthday experience, not template | LOCKED |
| D002 | Oct 2026 | Tone | “Playful outside, emotional inside” (Option C) | LOCKED |
| D003 | Oct 2026 | Creative mix | Deliberate cinematic + creative digital + artistic/handmade mix (Option D) | LOCKED |
| D004 | Oct 2026 | Atmosphere | Adaptive light/playful ↔ dark/magical as content demands | LOCKED |
| D005 | Oct 2026 | Navigation | Curated opening followed by free exploration | LOCKED |
| D006 | Oct 2026 | Scope | 22 discoveries are ONE component of something much larger | LOCKED |
| D007 | Oct 2026 | Anti-generic | No autonomous images, cakes, generic landmarks, AI girl, filler | LOCKED |
| D008 | Oct 2026 | Originality | Avoid Zoya copy, repeated cards, chapter loops, one motif everywhere | LOCKED |
| D009 | Oct 2026 | Media facts | No Pariii photo, calls or voice notes; video may use creator own voice/avatar | LOCKED FACT |
| D010 | Oct 2026 | Removed | Kedarnath postcard + Rasmalai experience | REJECTED |
| D011 | Oct 2026 | Respect | Her prior request not to receive similar site must be acknowledged; opt-out | LOCKED |
| D012 | Oct 2026 | Engineering | Google Antigravity + Gemini Flash coding; React/TS/modern stack proposed | TOOL CHOICE LOCKED; exact architecture PROPOSED |
| D013 | Oct 2026 | Project gift set | Physical gift, handwritten letter, separate birthday video, website | LOCKED intent |

## Pending approval queue (strict)
| Item ID | Open item | Required owner decision |
|---|---|---|
| O001 | Overarching original site-wide concept | Choose after 3 divergent concept pitches |
| O002 | Signature scenes beyond 22 | Approve concept and purpose for each |
| O003 | 6 missing personal discovery territories | Verify personal basis and non-overlap, approve |
| O004 | Details of the 16 SHORTLISTED ideas | Approve/merge/remove, interaction & copy |
| O005 | Visual design system | Fonts, palette, layout grammar, key screens, motion language |
| O006 | Specific visual/audio assets | Per-asset permission, rights and source |
| O007 | Exact user-voice birthday copy | Final text verified and publication approved |
| O008 | Video script/embedding | Actual video made and integration agreed |
| O009 | Actual donation/physical gift facts | Confirm if occurred, not speculative |
| O010 | Privacy/protected deployment | Decide and verify access plan |
| O011 | Signature finale details | Original personal ending with explicit approval |

## Append every new decision in this format
```text
Decision ID: D0XX
Date/time:
Feature/design element:
Current state: OPEN/PROPOSED/SHORTLISTED/LOCKED/REJECTED/PUBLICATION_APPROVED
Exact owner instruction (quote):
Reason / relationship to project principles:
Alternatives considered:
Files/experiences affected:
No-change constraints:
Implementation and QA implications:
Owner signoff reference:
```

## Conflict-resolution behavior
If owner says “No, not like this” or removes an element, update status to REJECTED immediately and remove its influence from future work; don't reintroduce under a new decorative name. If an old proposal contradicts a newer explicit rejection, newer rejection wins.
