# 15 — QUALITY ASSURANCE / MANUAL TESTING / PRE-LAUNCH CHECKLIST

> Keep a dated checkoff copy after actual testing. A checkbox is **not** a claim of testing until screenshots, commands or device outcomes exist. Don't fabricate Lighthouse scores, iPhone tests or asset licenses.

## A. Creative acceptance
- [ ] Concept is distinctly original and approved, not copied from prior Zoya website.
- [ ] At least two major scenes have clearly different interaction/layout grammars from each other.
- [ ] 22 doesn't dominate website headings/navigation/art; a viewer can appreciate site without counting.
- [ ] No automatic generated/stock cakes/balloons/mountains/AI girl or random filler.
- [ ] Doodles, nickname typography and DM appear **only where meaningful**, not as all-over theme.
- [ ] Big visually interesting moments beyond 22 collection exist and have owner approval.
- [ ] All copied personal moments specifically approved; no fictional memories/favourites.
- [ ] End is accessible without completing 22/22; no emotionally coercive microcopy.
- [ ] Site respects her stated wish and allows skip/exit.
- [ ] Compared with ClickIt Zoya, repetitive cards/modals/chapters are substantially reduced.

## B. Mobile/visual regression
- [ ] iPhone Safari real device view tested (or explicitly report untested).
- [ ] Chrome Android viewport / actual Android where possible.
- [ ] Widths 320, 360, 375, 390, 414, 430; tablet 768; desktop 1280/1440.
- [ ] Safe areas and dynamic address-bar behavior tested.
- [ ] No sideways scroll, clipped heading, overlapped navigation, invisible tap target, accidental selection.
- [ ] Minimum sensible tap targets and responsive gestures.
- [ ] Intentional whitespace and compositional balance in desktop (avoid huge empty voids).
- [ ] Every text passage readable and contrast accessible; no pastel-on-pastel.
- [ ] Reduced-motion variant doesn't hide or block content.
- [ ] Typographic layout works with system font fallback and 200% text zoom.

## C. Interactions and state
- [ ] Curated intro skippable, no forced wait and obvious leave action.
- [ ] After intro, free exploration genuinely possible.
- [ ] Every main experience has clear close/back; browser Back is sensible.
- [ ] Keyboard tab order and visible focus; Escape closes overlay; focus restored.
- [ ] Tap alternative for any drag/hover interaction.
- [ ] Previously seen experience can be revisited; local persistence is functional if approved.
- [ ] Progress does not gate final, and user can reset local progress if needed.
- [ ] Animations cancel/clean up, no duplicate timers or listeners.
- [ ] Audio off by default, mute/pause/stop works, no auto sound.
- [ ] Error/reload/back mid-interaction doesn't break session.

## D. Data/privacy/source fidelity
- [ ] `public/`, `dist/`, Git diff/history and network payloads contain NO raw Instagram export or chat ZIP.
- [ ] Selected published text has `PUBLICATION_APPROVED` status + source review.
- [ ] No unapproved third-party photos, personal handles, dates, names or private screenshots.
- [ ] No invented details / secret favourite tracks / fabricated work events.
- [ ] Feeding-someone scene says it happened only if owner confirmed.
- [ ] Owner's original artwork/doodle used with ownership verified; no fake likeness of Pariii.
- [ ] All fonts, tracks, embedded players and assets have rights and approved sources.
- [ ] No hardcoded passwords/API keys or mistaken assumption that frontend 4-digit login is security.
- [ ] Hosting/access protection appropriately matches privacy decision; `noindex` isn't considered security.

## E. Engineering / performance
- [ ] `npm install` (or approved package manager) succeeds.
- [ ] TypeScript typecheck passes.
- [ ] Production build succeeds.
- [ ] Lint passes if configured; no broken imports or asset 404s.
- [ ] No serious console errors or unhandled promises.
- [ ] Reasonable first paint, font layout stability, image sizes optimized, heavy scenes lazy-loaded.
- [ ] Scene animations work at usable speed on actual target phone; no giant unnecessary WebGL.
- [ ] Respect browser visibility changes; no wasted looping animation in hidden tabs.
- [ ] No excessive network requests, trackers, autoplay media or gigantic audio downloads.
- [ ] Reflected input escaped and no unsafe innerHTML.

## F. Launch readiness
- [ ] All approved copy proofread in creator's voice with accurate emojis/spelling.
- [ ] Final link tested from a **fresh device/browser** and privacy gate validated.
- [ ] Correct 10 Nov 2026 / age 22 used wherever birthday metadata appears.
- [ ] Loading, offline/unavailable and missing optional media scenarios display appropriate fallback.
- [ ] Git tag/known-good commit available; rollback plan exists.
- [ ] Clear handoff of any manual upload to creator; no false 'delivered' claims.
- [ ] Owner explicitly approved sending the website (recipient still free to decline).

## Bug report format
```text
Browser/device, resolution, OS:
Repro steps:
Expected vs observed:
Screenshot/video evidence:
Console/network errors:
Severity/blocker:
Files implicated:
Fix scope and regression tests:
```
