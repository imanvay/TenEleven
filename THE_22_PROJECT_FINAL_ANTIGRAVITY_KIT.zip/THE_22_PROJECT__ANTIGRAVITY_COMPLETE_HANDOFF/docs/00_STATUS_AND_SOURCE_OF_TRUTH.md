# 00 — SOURCE OF TRUTH: FACTS / APPROVAL LEVELS / REJECTED DIRECTIONS

## Approval terminology
- **LOCKED:** Owner explicitly selected or repeated a decision. Respect unless they explicitly revise.
- **FACT VERIFIED:** Supported by supplied messages or explicit user statement. **It is NOT publication permission.**
- **SHORTLISTED:** Owner previously selected an idea as worth developing, **not** a final visual layout, scope, quotation or implementation.
- **PROPOSED:** Assistant's idea; useful for brainstorming, not selected by owner.
- **OPEN:** Critical decision not yet made; no auto-resolution.
- **REJECTED:** The owner ruled it out; must not reappear unless they explicitly reverse.
- **PUBLICATION_APPROVED:** Exact personal copy/media specifically reviewed and cleared by owner for the eventual birthday site. **Currently none** in this package.

## LOCKED — creative and UX
| Category | Decision |
|---|---|
| Goal | Exceptionally crafted, **non-generic** birthday experience larger than The 22 Project sub-feature |
| Recipient & time | Pariii / Buddhuuu; 10 November 2026, turning **22** (not 23) |
| Emotional rhythm | **Playful outside, emotional inside** (owner chose C) |
| Mix | Magical/cinematic + creative digital playground + artistic/handcrafted (owner chose D) |
| Atmosphere | Adaptive light/playful ↔ dark/magical where scene/story requires (owner chose C) |
| Navigation | **Curated opening → free exploration** (owner chose hybrid C) |
| Device | Mobile-first, usable and crafted on desktop |
| Originality | New top-level concept, not template, gimmick or clone of earlier site |
| Images | Antigravity cannot autonomously source or generate images/assets; propose for explicit approval |
| Avoid | Generic cake, balloons, random scenic image, AI person, invented chat, repetitive cards, 22 fixation |
| Boundaries | Recipient can decline/exit; her earlier 'don't make that website' request is real and respected |
| Gift separation | Letter, physical gift, creator-voiced cartoon-avatar video, website are distinct contributions |
| Personal anchors | Only accurate, creator-reviewed real moments; preserve friendship framing |

## FACT VERIFIED — from user / chat data, not yet publishable
- Recipient has no creator-accessible photographs and no voice notes/calls have been exchanged.
- Her work includes network engineering/security; she cares about thoughtful gestures and Bappa.
- First July 28 DM about fan edits, `Random? right` reply; nickname changes; funny badam exchange; friendship advice.
- She declined being given the same sort of birthday website. The fact that owner wishes to create one does **not** erase her expressed boundary.

## SHORTLISTED — sixteen content territories, not finished features
First DM; `Random? right`; Nicknames; Living Doodle; Badam Game; Typing Dictionary; Pariii.exe; Things You Notice; Friendship Advice; Chill Pariii; Pariii Radio; Workday Appreciation; Bappa Blessing; Helping Someone; Personal Keepsake; Final Surprise.

## OPEN — do NOT silently decide
1. A genuine original **overall creative identity** and interaction grammar that does not revolve around 22/chats/doodles/floating objects.
2. Specific signature scenes **outside** the 22 discovery set.
3. The **six missing** personal discovery areas, plus avoiding overlap among the 16.
4. Final visual layouts, original artwork direction, exact palettes/font licensing, brand mark, accessibility test details.
5. Any actual personal quote to publish, all final onsite copy and author's intended emotion.
6. Privacy/access method and precise deploy URL; whether to include/integrate video/audio; if gift actions were actually completed.
7. Whether each shortlist item should be standalone, combined, changed or dropped.

## REJECTED — hard stop
- `Kedarnath postcard` interaction; `Rasmalai` interaction (specifically removed).
- Whole website as one doodle motif, or all screens revolving around 22, or generic floating-object/card-grid proposal.
- Cloning ClickIt Zoya / more of its chapter + card + collectible formula.
- Autonomous cake/mountain/AI-girl images; generic birthday background filler; making up her likeness/voice.
- Claiming the recipient has approved the surprise, or making her spend a minimum time / complete every task.

## **Important anti-assumption note**
Even if detailed past assistant wireframes exist (e.g. upper/middle/lower canvas, floating phone, 390×844 wireframe, 40-second opening, palette swatches, proposed object coordinates), these were **assistant experiments, not final user approvals**. The user later challenged the narrow approach. These are not binding build requirements. Only the *higher-level locked principles* stand.
