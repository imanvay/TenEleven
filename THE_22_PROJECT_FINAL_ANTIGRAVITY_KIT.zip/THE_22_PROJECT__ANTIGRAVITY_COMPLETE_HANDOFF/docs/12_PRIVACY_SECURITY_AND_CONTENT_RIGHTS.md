# 12 — PRIVACY, ACCESS, CONSENT, COPYRIGHT AND ETHICAL DESIGN

## Primary relationship boundary
Recipient **repeatedly declined a birthday website of the sort creator built for someone else**. This is an actual preference, not a playful obstacle. Creator may make a personal gift but must not assume she wants it or pressure her to use it. Acknowledge honestly, offer an easy skip/exit and accept a 'no'. The experience must never claim her prior consent.

## Instagram export handling (very important)
- The original creator-provided old/new Instagram message exports contain **thousands of private messages** and attachments. DO NOT put the full archive, raw ZIP, HTML export, parsed JSONL, attachment folders or third-party communications into a frontend repo, static website, Vercel project or AI-agent workspace.
- This handoff intentionally contains limited *research descriptions* of selected details, not raw chats. Even these short excerpts require creator approval before publication.
- For an approved moment, manually add only the exact minimal snippet required, with clear attribution and verified context. Avoid third-party personal data, private photos and sensitive discussions.
- Treat a published Vercel URL as public unless effective protection is configured. `noindex` only asks crawlers not to index; it **does not provide privacy**.
- Client-side `password === '1234'` merely obscures UI; inspect-source/network can still reveal text and assets. If protection is needed, use actual deployment authentication or server-side gating.
- No precise shipping address, personal phone, email, private names not needed to tell the story, workplace identifiers or social login credentials in the code.

## Accuracy, source and quote ownership
- Never fabricate screenshot bubbles, dates, sender, exact quote, favourite music, photos or voice. Source summaries have `FACT VERIFIED` status, not `PUBLICATION_APPROVED`.
- Respect screenshots/doodles source ownership and third-party content. Use only artwork owner supplies/authorizes or original lawful assets.
- Music streaming embeds must follow rights/terms, and any downloaded audio must be licensed or creator-owned. Do not bundle song lyrics.
- If discussing feeding someone in need, claim it only after creator confirms it occurred. Do not display identifying photos of beneficiary without informed consent; omit them by default.
- Respect spiritual themes. No unrequested AI depiction of religious figures or randomly selected temple images.

## Technical privacy defaults
- Prefer privacy-preserving hosting: protected preview, no trackers/analytics by default, minimum data, optional local-only discovery persistence.
- Security review of deployment URLs and build assets before sharing.
- Check `public/`, `dist/`, network requests, source maps and Git history for leaked exports, passwords, API secrets and sensitive names.
- No externally hosted fonts or media that create surprise tracking if privacy is a concern; document approved font/media services.
- Provide a simple 'close/leave' option at the intro. Avoid guilt-oriented metrics such as “You only saw 7/22, finish it!”
- If recipient dislikes or declines the gift, creator must respect it; no follow-up tracking/notifications designed to pressure engagement.

## Safety and age-appropriate friendship treatment
Focus on a warm, platonic friendship gift. Avoid immersive romantic roleplay, suggestive content, possessive declarations, comparisons about appearance, or creating a fictional intimate history. Do not portray invented photos/calls/meetups as real.

## Review checklist before launch
1. Every quote from actual chat has sender/date verified, owner-approved for display.
2. No complete raw export bundled, linked or in any source map.
3. No third-party private conversation/media in front-end assets.
4. No exposed secret, public 4-digit client-side 'security', unapproved analytics.
5. Audio/image/font rights and ownership reviewed; no copyrighted lyrics.
6. Recipient can decline or exit; no manipulative language or obligatory tasks.
7. At most minimal sensitive personal details are present and hosting is protected if desired.
