# 08 — MOBILE EXPERIENCE, INPUT, MOTION, AUDIO, ACCESSIBILITY

## Device priority
The recipient is likely to open from a phone; design **mobile first**, not a desktop webpage squashed into 390px. Build intentionally for narrow widths; polish desktop as a first-class fallback. Test at width ~320, 360, 375, 390, 414, 430, 768 and desktop 1280+. Keep Safari browser UI and dynamic address-bar changes in mind.

## Responsive decisions
- Content never relies on hovering or right-clicking; all touch inputs have clear hit regions (~44×44 CSS px when feasible).
- Avoid horizontal overflow, overlapping text, illegible type under 14px for primary content, or text embedded inside a static image.
- Respect safe-area insets (`env(safe-area-inset-*)`), dynamic viewport units (`dvh/svh` with fallback), orientation changes and device zoom.
- No pinching/zooming required to explore; no tiny object hotspots; if user can drag, user can tap or keyboard-control an equivalent.
- Fonts maintain hierarchy without huge full-screen headings blocking content. Motion does not obscure interactive controls.

## Curated opening
- Should acknowledge Pariii's request not to receive the same kind of site; offer a respectful obvious opt-out and easy skip/continue.
- Hook should create curiosity through intentional art direction, NOT 'wait 30 sec until timer finishes'.
- Curated is **not** synonymous with forced: user can tap through or skip longer motions; content is visible and understandable with reduced-motion enabled.
- The first DM can appear as a supporting opening beat if concept chosen and owner approves, not mandatory master metaphor.

## Free exploration
- Selected concept may be stage-like, editorial, layered tool interaction, etc.; navigation must remain intuitive.
- Keep location/context when returning from a surprise; preserve scroll and focus, avoid resetting site to top.
- The 22 subsystem must be discoverable without cluttering the home with 22 equal-size objects.
- The finale is accessible without arbitrary progress gates.
- Provide orientation ('where am I / how do I go back?') but avoid large persistent UI obscuring artwork.

## Motion principles
1. **Immediate input acknowledgment:** button press/tap feedback generally under ~100ms.
2. **Functional transition:** a transform or crossfade should explain spatial/context change.
3. **Characterful humour:** snappy, sparse, purposeful; scene-specific not every object bouncing.
4. **Gentle depth:** emotional transition may slow/quiet and lower visual contrast elsewhere; do not darken text to illegibility.
5. **No continuous distraction:** endless background particles, blur filters, WebGL nebula or constant shake as default forbidden.
6. **Motion reduction:** respect `prefers-reduced-motion: reduce`, offer static reveal/instant state change with identical content.

## Suggested timing bands (not locked animation spec)
- Tap acknowledgment: ~80–150ms.
- Small playful affordance: ~180–350ms.
- Object-to-scene: ~350–700ms.
- Intentional art-directed reveal: ~650–1200ms if skippable, depending on scene.
Never force all scenes into these durations, or make users wait until sound/animation finishes before reading.

## Audio policy
- Sound off by default. Offer explicit user control; no automatic autoplay, no surprise volume changes.
- Separate original sound design from copyrighted songs. Audio is optional across all experiences; the silent version must feel complete.
- Stop/pause when tab hidden or user exits full-screen interaction; handle mobile restrictions and buffering; show loading/error gracefully.
- If creator supplies his own recorded birthday voice, use only approved asset and decide overlap with separate video deliberately.

## Accessibility
- Semantic buttons/links, focus rings, Escape/Back support, alt descriptions for meaningful art, decorative SVG `aria-hidden`.
- Dialog focus trap and focus restoration; no invisible dismiss buttons; screen reader announcements only where useful.
- Sufficient color contrast; don't use pastel on pastel text (problem observed in previous site).
- All key information accessible as readable text, independent of animation or image.
- Avoid rapid flashes, intense parallax, surprise loud sound and repetitive stimulation.
- Test keyboard, screen reader basics, touch, slow network and disabled JS fallback message.

## Real user testing (minimum)
- iPhone Safari portrait (real phone if available), Chrome Android representative viewport, desktop Chrome/Edge.
- Warm load and cold load; OS reduce-motion; audio allowed/blocked; landscape; 200% zoom.
- Touch every experience with one thumb. Return, revisit and final message work; no dead ends.
- Measure actual device FPS and load; decorative effects must not make reading/typing laggy.

## Empty vs expressive whitespace
Intentional whitespace is valid only when it creates clear visual hierarchy. The prior ClickIt Zoya screen recording showed multiple wide areas with small centered content; avoid replacing this with more random ornament. Instead, use well-composed scale, balance, purposeful full-screen art and genuinely responsive placement.
