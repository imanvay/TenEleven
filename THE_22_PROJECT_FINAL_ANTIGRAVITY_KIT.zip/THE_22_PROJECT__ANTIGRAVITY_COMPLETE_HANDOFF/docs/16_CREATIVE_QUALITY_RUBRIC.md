# 16 — CREATIVE QUALITY RUBRIC (SCORE AND HARD FAILS)

Use on each prototype and final site. Score only what was actually observed, not what the agent promises.

| Dimension | Maximum | What earns a high score |
|---|---:|---|
| Original art direction | 25 | Distinctive composition and identity, not a palette-swapped template |
| Personal specificity / truthfulness | 20 | Recognizably Pariii and this friendship; no invented traits or copied quotes |
| Interaction originality / diversity | 20 | Meaningful different mechanics and transformations; not 22 identical modals |
| Mobile craft / performance | 15 | Clear touch UX, reliable Safari/Android, controlled motion, maintainable |
| Emotional pacing / respect | 10 | Playful then thoughtful, sincere, no guilt or completion pressure |
| Accessibility, privacy and rights | 10 | Readable, reduced motion, optional sound, content approvals, no leaks |
| **TOTAL** | **100** | **No score guarantees launch if a hard-fail is present** |

## Suggested thresholds
- **90–100:** Strong enough to consider a flagship quality benchmark, after all tests.
- **80–89:** Good but specific art/interaction refinements needed.
- **65–79:** Looks/feels under-designed or inconsistent, revisit concept execution.
- **Below 65:** Rework; don't compensate by adding more features.
These bands are a review aid, not factual quality measurements.

## Automatic hard-fail (regardless of points)
- Autonomous AI/stock cake/balloons/random landscape/AI face without explicit owner authorization.
- Private chat archive or sensitive third-party material exposed in build.
- Invented conversations, fake call/voice/photo, fake gift/donation completion.
- Romantic or guilt-driven pressure; ignoring her stated reluctance.
- Whole design based on numbered 22 tiles/doodles/floating objects after owner explicitly rejected this.
- More or less a copy of ClickIt Zoya's chapter/card/star formula.
- Finale blocked behind finishing all experiences, or site unusable on mobile.

## A prototype is worth approving only if it answers:
1. What makes this **original** beyond styling?
2. What makes it **Pariii-specific**, supported by source/owner?
3. Why is this interaction meaningfully different from the last one?
4. Does it work beautifully and comfortably on a real phone?
5. Could this scene still work with every generated image removed?
6. Is it respectful, private and free of manipulation?

## Anti-beauty-filler question
If a decorative asset doesn't help **understanding**, **emotion**, **identity**, or **interaction**, remove it instead of creating a new image.
