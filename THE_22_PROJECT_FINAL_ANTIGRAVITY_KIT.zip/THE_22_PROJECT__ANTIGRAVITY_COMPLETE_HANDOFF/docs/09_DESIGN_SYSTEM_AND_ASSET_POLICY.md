# 09 — DESIGN SYSTEM / VISUAL ASSET APPROVAL RULES

## Crucial: visuals not yet LOCKED
An earlier assistant suggested lavender/cream/blush/plum/gold and showed mood images, but **the user approved the adaptive mix of styles, not any exact palette, logo, typeface or particular screenshot.** Do not use prior art references as direct assets. The final creative concept must establish its own cohesive design system, reviewed before implementation.

## A premium design system is rules, not a theme template
When proposing final tokens, explain:
- Palette: expressive light/dark states, elevated neutrals, one or two semantic accent roles; text contrast verified.
- Typography: a display voice for key scenes, a readable text family, optional limited handwriting role. Use legal web fonts with correct licenses; never share font files casually.
- Layout: alignment, rhythm, proportions and whitespace; purposeful asymmetric compositions; mobile and desktop variants.
- Surface language: do not default to every panel as a glassmorphic/rounded-card with shadow.
- Iconography: simple consistent meaning, not an emoji soup or random Lucide symbols on every tile.
- Original visual assets: authored for purpose, meaningful to recipient or interactive concept, high quality at every size.
- Motion language: consistent intent (functional/personal/playful/quiet) across varied scene compositions.

## Image/asset approval is ALWAYS opt-in
**No autonomous `imagegen`, web-image search, unsplash, placeholder stock photos, AI girl portraits, faux memories, cakes, balloons, mountain landscapes, temple images, branded photos, scraped drawings or copyrighted visual downloads.**

For EACH external/generated/non-code asset, submit an **Asset Proposal** before making or adding it:
1. Filename/asset ID and which scene uses it.
2. Purpose — why does this visual belong and why is text/SVG insufficient?
3. Proposed art direction, size/aspect/resolution, color compatibility.
4. Method: owner-provided, original creator artwork, original SVG/CSS, explicitly licensed asset, or AI generated **only if owner explicitly approves**.
5. Source rights and whether it depicts any real person, religious figure or private content.
6. Mobile load/performance impact and graceful fallback.
7. Exact approval needed.
Only after explicit owner approval can you create/include it. **Do not treat “Make it beautiful” as asset approval.**

## Code-built visuals vs asset restriction
CSS/SVG/Canvas styling is permissible *after scene concept approval*, because otherwise no sophisticated frontend could be built. But even procedural visuals must be intentional and subject to art-direction review. The user rejected uncontrolled decorative additions, not craft or illustration as such.

## Expected visual variety
A project may contain:
- One intense cinematic full-screen visual reveal.
- One sharply designed playful interactive tool.
- One handcrafted original drawn detail.
- One minimalist reflective typographic scene.
They need **not** share identical surface shapes; unity comes from disciplined typography, spacing, transitions, sound and palette logic.

## Prohibited default art
- Cake/candles, party balloons, stock gift box, generic heart rain, repeated bows or pink confetti.
- Kedarnath postcard/imagery and Rasmalai interaction (explicitly removed).
- Random travel/scenic photo not tied to confirmed user-approved memory.
- AI-generated woman/face, invented Pariii lookalike, fictitious photos, 'couple' imagery.
- Doodle backgrounds dominating site. Only selected owner-provided genuine drawings if approved.
- Random number 22 motifs on every page.
- Gradient blobs used to hide weak layout composition.

## Art feedback criteria (pass/fail)
- Does this look like an original authored piece, or like an AI template landing page?
- Does the primary screen still look polished with placeholder art removed?
- Does the hero work at 320px width as well as desktop?
- Is everything legible with decorative layers disabled?
- Is visual variety earned by interaction/content differences, not random styling?
- Could a reviewer identify the personal narrative reasons for the most prominent elements?
- Are any images, quotations, fonts or songs unlicensed/unapproved?

## Document approval
After the chosen concept, create a versioned **Visual Direction Sheet** containing: mood words, typography specimens, token proposal, 3 high-fidelity keyframe descriptions/mockups, animation choreography, screen densities, asset list. Owner signs off before building. Add decision to `17_DECISION_LOG_AND_OPEN_ITEMS.md`.
