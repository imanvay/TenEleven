# 04 — HOW TO CHOOSE THE OVERARCHING CREATIVE CONCEPT (STILL OPEN)

## This is the largest remaining creative decision
The owner has repeatedly rejected converging on one motif. DO NOT assume the whole site is a scrolling card grid, floaty universe, doodle room, 22 objects or chat simulator. The overarching creative premise must be chosen **before** Antigravity generates code.

## Required first deliverable: 3 truly different concepts
Each direction must contain:
1. **One-sentence central idea** that explains why the experience is special without saying '22 gifts'.
2. **Distinct interaction/navigation grammar:** how she moves from moments to activities, without chapters or identical cards. Choose among different mechanisms — not three variants of floating icons.
3. **Opening scene**: what she sees and controls (option to decline); exact emotional purpose.
4. **Two truly memorable signature visual set-pieces outside the 22 discovery area**.
5. **Three example transformations of personal content** from E01–E13; distinguish direct quote versus metaphor.
6. **Visual/art direction:** typography, shapes, lighting, editorial composition, motion rhythm (no auto-generated assets).
7. **Mobile feasibility** with constraints, reduced-motion analogue, performance approach.
8. **How it differs from ClickIt Zoya and from the other two concepts.**
9. **What might fail**, and what we'd prototype in 1–2 days to de-risk.
10. **What remains unknown**, with at most 3 essential owner questions.

## Diversity test — fail unless clearly different
If Concepts A/B/C all involve a dark-purple canvas, 22 floating objects, taps opening modals, and a final letter, they are **one concept with 3 skins**, not three.
Different concepts must differ in *narrative logic, spatial interaction, visual identity and signature moments*, not merely fonts/palette.

## Optional ideation seed examples ONLY (not approved choices)
- **Kinetic editorial performance:** typography, cut-paper/sound-driven stagecraft and responsive choreographed transitions; each story has bespoke composition; playful → quiet via typographic rhythm, not a floating-object map.
- **Creative studio of living experiments:** non-generic interactive micro-tools inspired by both friends' editing/technical interests, with scene-specific visual systems; not a literal OS clone and not endless software windows.
- **A responsive small digital theatre:** several authored 'acts' as visual set-pieces, with non-linear optional experiences placed around an open stage; avoid visible numbered chapters and do not overuse curtains/stages.
These are **only prompts for divergent ideation**, not a requirement to choose one or restrict the model to them.

## Scoring (100 points)
- Original identity and non-templated design — 25
- Faithfulness to her real personality and real memories — 20
- Distinctive full-screen interactions and presentation variety — 20
- Practicality/performance on real mobile — 15
- Respectful emotional pacing and freedom — 10
- Accessibility, maintainability, privacy — 10
**Hard-fail override:** generic imagery; made-up private content; cloned prior site; dependence on completing all 22; ignoring recipient objection.

## Approval protocol
- Pitch concepts with clear side-by-side contrasts and a 'do not build yet' banner.
- Let owner combine ideas if desired; document the final **chosen concept** in `docs/17_DECISION_LOG_AND_OPEN_ITEMS.md` with name, distinguishing features and explicit rejected alternatives.
- Only then make high-fidelity composition and motion direction. Do not treat the concept selection itself as authorizing all artwork/quotes.
