# Asset Approval Request — TEMPLATE

**Asset ID:** A###   **Status:** OPEN   **Requested by:** Agent

1. **Exact visual need and approved scene:**
2. **Why code/typography/SVG alternatives are not sufficient:**
3. **What the asset depicts** (no invented recipient likeness/memory):
4. **Proposed style, composition, aspect ratio, mobile sizes:**
5. **Origin:** creator-owned / custom human / procedural design / licensed external / AI generation (only if owner explicitly permits)
6. **License and credits / privacy concerns:**
7. **Performance target / fallbacks:**
8. **Files where used:**
9. **Originality test** (not cake/balloons/generic scene / arbitrary imagery):
10. **Owner explicit approval (date, scope):**

**Do not produce or insert an asset while the request is still OPEN.**
