# Feature Review — TEMPLATE

**Feature ID/title:**   **Date:**   **Owner-approved spec link:**

## Creative review (evidence, not promises)
- Specific personal detail and why it matters:
- Does it feel like a generic template after name swap?
- Is the artwork/typography deliberately composed?
- Does the interaction do something beyond opening a card/modal?
- Does this fit the chosen site-wide concept while still being distinctive?
- Is it a 22 discovery OR a site-wide flagship moment?

## Technical QA
- Device/browser screenshots, links, motion/video:
- Widths tested:
- Reduced motion / audio off / focus / back/exit:
- Build/typecheck/lint output:
- Performance and load issues:
- External/new asset audit:
- Publication-approved copy/rights audit:
- Private export/secret leak audit:

## Outcome
- [ ] APPROVED
- [ ] NEEDS REVISION (specific instructions)
- [ ] REJECTED (record reason; don't silently revive)
- New/updated decision log ID:
- Rollback/commit reference:
