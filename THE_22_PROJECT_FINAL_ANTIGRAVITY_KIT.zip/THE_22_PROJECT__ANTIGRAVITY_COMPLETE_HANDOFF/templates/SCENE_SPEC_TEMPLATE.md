# Scene Specification — TEMPLATE (copy per scene)

**ID:** S###   **Title:** TBD   **Status:** OPEN

## 1. What is this doing here?
- One-line story/interaction thesis:
- Website-level flagship or 22-discovery item?
- Real personal grounding/source ID:
- Emotional role, with no claim of guaranteed recipient reaction:
- Unique difference from earlier scenes:

## 2. Visual direction (approval needed)
- Original composition: mobile first and desktop adaptation:
- No-image fallback / CSS/SVG/typography approach:
- Typography, palette mode, visual rhythm:
- Asset proposal IDs and rights/source:
- What NOT to generate/imitate:

## 3. Interaction choreography
- Entry from the overarching navigation:
- User gesture / keyboard alternative:
- Immediate feedback:
- Main state change / meaningful reveal:
- Exit/replay/back and progress semantics:
- Sound off / no-motion equivalents:

## 4. Content integrity
- Exact quote IDs `C###`:
- Creator original copy and publication approval:
- Third-party privacy/redactions:
- Unconfirmed claims to withhold:

## 5. Engineering and QA
- Files in scope, files explicitly out of scope:
- Components/state/data touched:
- 320/390/430/768/1440 viewport behaviour:
- Accessibility and performance criteria:
- Test evidence and known limitations:
- Owner approval and date:
