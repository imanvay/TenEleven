# Optional code review helper

From the project root after a frontend exists:

```bash
python scripts/preflight_privacy_check.py
```

This flags obvious chat export or sensitive file names under `src/`, `public/`, and `dist/`, and notes media files not listed in `scripts/approved_assets.txt`. It does **not** inspect actual images or prove content has no private information. It is one automated guard; manual review under `docs/12_PRIVACY_SECURITY_AND_CONTENT_RIGHTS.md` and `docs/15_QA_TESTING_AND_LAUNCH.md` remains mandatory.

If your project uses a different directory structure, adapt `SCAN_DIRS` after explicit review.
