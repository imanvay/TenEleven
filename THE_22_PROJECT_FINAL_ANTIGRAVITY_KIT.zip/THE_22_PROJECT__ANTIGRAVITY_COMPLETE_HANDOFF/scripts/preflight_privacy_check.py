#!/usr/bin/env python3
"""Heuristic local-only preflight before deploying The 22 Project.

Run from project root: python scripts/preflight_privacy_check.py
This does NOT replace human content/asset review or security testing.
"""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
SCAN_DIRS=['public','src','dist']
PRIVATE_NAME_HINTS=('message_1.html','message_2.html','_chat_parsed.jsonl',
                    'firsebana_liya_','instagram_export','chat_export',
                    'screen recording 2026-10-20 023311.mp4')
SENSITIVE_EXT={'.zip','.jsonl','.har','.sqlite','.db','.pem','.key','.env'}
MEDIA_EXT={'.png','.jpg','.jpeg','.webp','.gif','.svg','.mp4','.mov','.mp3','.m4a','.wav','.ogg'}
ALLOWLIST=ROOT/'scripts'/'approved_assets.txt'
approved=set()
if ALLOWLIST.is_file():
    approved={x.strip().replace('\\','/') for x in ALLOWLIST.read_text().splitlines()
              if x.strip() and not x.lstrip().startswith('#')}

errors=[]
warnings=[]
for directory in SCAN_DIRS:
    base=ROOT/directory
    if not base.is_dir():
        continue
    for p in base.rglob('*'):
        if not p.is_file():
            continue
        rel=p.relative_to(ROOT).as_posix()
        lower=p.name.lower()
        if any(hint in lower for hint in PRIVATE_NAME_HINTS):
            errors.append(f'PRIVATE EXPORT-LIKE FILE: {rel}')
        if p.suffix.lower() in SENSITIVE_EXT or p.name == '.env':
            errors.append(f'SENSITIVE OR ARCHIVE FILE: {rel}')
        if p.suffix.lower() in MEDIA_EXT and rel not in approved:
            warnings.append(f'MEDIA NOT ON APPROVED-ASSET LIST: {rel}')
        if p.stat().st_size > 15*1024*1024:
            warnings.append(f'LARGE FILE ({p.stat().st_size//(1024*1024)} MB): {rel}')

print('The 22 Project — Privacy / Asset Preflight (heuristic)')
print('Roots checked:', ', '.join(d for d in SCAN_DIRS if (ROOT/d).exists()) or '(none yet)')
for err in errors:
    print('ERROR:', err)
for warn in warnings:
    print('REVIEW:', warn)
print(f'{len(errors)} errors, {len(warnings)} review warnings')
if errors:
    print('FAIL: remove or protect suspicious files; do not deploy.')
    sys.exit(1)
print('No obvious archival leak found. Manual privacy, content and asset checks are STILL required.')
