# THE 22 PROJECT — COMPLETE ANTIGRAVITY CREATIVE + ENGINEERING HANDOFF

**Version:** 2.0 • Prepared 20 October 2026 • **Recipient's birthday:** 10 November 2026

> **THIS IS A CONTEXT AND PRODUCTION BRIEF, NOT A REQUEST TO AUTO-GENERATE A WEBSITE.**
>
> The creator explicitly rejects generic birthday imagery, generic templates, repetitive cards, made-up personal details and an entire site revolving around “22,” doodles or a single DM. The real goal is an original, beautifully art-directed **birthday experience bigger than the 22 discoveries**.

## START HERE — owner (5 steps)
1. Extract this ZIP. Open **one clean project folder** in Google Antigravity.
2. Copy `AGENTS.md`, `docs/`, `prompts/` and `templates/` to the **root of that project**. Keep all files together; relative paths matter.
3. Paste the contents of **`prompts/00_FIRST_MESSAGE_TO_ANTIGRAVITY.md`** into Gemini Flash.
4. Expect an **understanding/audit + three truly different top-level creative directions**, **NOT generated website code**. Choose/approve the concept before permitting implementation.
5. After each approved milestone, make Gemini update the decision log and verified content manifest; keep Git commits small and test the site on a physical phone.

## What is already locked?
- Friend named **Pariii**, affectionately **Buddhuuu**; birthday **10 Nov 2026**, turning **22**. Creator's nicknames include **Bhonduu/Bhonduui Ram/Golu Moluuu**.
- **Mobile-first**, also polished on desktop. **Playful outside, emotional inside.** An intentional blend of cinematic/magical, experimental playful digital design and handmade authenticity.
- **Adaptive visual modes:** light/airy/playful and dark/quiet/magical, **only when a scene earns the transition**.
- **Brief curated opening, then free exploration**. No mandatory numbered chapters; final message must never require collecting all items or winning games.
- **Originality over count**. The collection of 22 personally grounded discoveries is **one component**, not the website's theme, navigation or all its content.
- **Zero autonomous generated/stock imagery**. Major visual assets need the creator's explicit approval. No cakes, balloons, random landscapes, Kedarnath imagery, AI-generated girl/face, generic pink-birthday kitsch.
- No fabricated conversation, personal memories, interests, favourite track, face, voice or relationship claims. No recipient photos/voice notes/calls available.
- Birthday website is one of **four different gifts**: physical gift, handwritten letter, planned creator-voiced/avatar video, website. Do not duplicate them.
- Recipient repeatedly said she **didn't want another website like the previous one**. Do not manipulate, conceal this fact or pressure her into opening it; she is free to decline.
- Prior benchmark **ClickIt Zoya** is feature-rich but card/gradient/chapter repetitive. **Do not clone it** or just increase the quantity.

## What remains intentionally OPEN?
- **One original site-wide creative concept** (not yet chosen). **Specific scene compositions and actual UI mockups**.
- Six further discovery concepts; the 16 identified ones are **shortlisted content territories**, not final approved feature implementations.
- Signature big experiences **outside** the 22 set: exact creative form, count, choreography.
- Actual colors/typography/assets; exact final voice and on-site copy; approved excerpt list; ending; hosting privacy method; final video embedding.

**Never report these as already finalized.** It is okay — and required — to stop and ask the owner at approval gates.

## Reading order — all documents
1. `AGENTS.md` — hard rules and agent workflow.
2. `docs/00_STATUS_AND_SOURCE_OF_TRUTH.md` — absolute status taxonomy.
3. `docs/01_CREATIVE_BRIEF.md` — ambition, emotional mission, audience, gift boundaries.
4. `docs/02_PERSONAL_CONTEXT_AND_EVIDENCE.md` — sourced moments, fact boundaries.
5. `docs/03_NON_GENERIC_ART_DIRECTION.md` — creative philosophy and negative examples.
6. `docs/04_CREATIVE_CONCEPT_APPROVAL.md` — how to pitch site-wide identities.
7. `docs/05_EXPERIENCE_ARCHITECTURE.md` — experience types and navigation, deliberately not a locked layout.
8. `docs/06_SIXTEEN_EXPERIENCE_SPECS.md` — detailed candidate implementation briefs.
9. `docs/07_TWENTY_TWO_DISCOVERY_PLAN.md` — selected/pending and originality criteria.
10. `docs/08_MOBILE_UX_AND_MOTION.md` — phone behaviours, interactions, states.
11. `docs/09_DESIGN_SYSTEM_AND_ASSET_POLICY.md` — art, typography, animation assets and requests.
12. `docs/10_COPY_AND_STORYTELLING.md` — text tone, emotional safety, example copy.
13. `docs/11_TECH_ARCHITECTURE.md` — coding stack, data, state, performance.
14. `docs/12_PRIVACY_SECURITY_AND_CONTENT_RIGHTS.md` — extremely important for chat excerpts.
15. `docs/13_CLICKIT_ZOYA_REFERENCE_REVIEW.md` — benchmark audit and what to surpass.
16. `docs/14_BUILD_PHASES_AND_APPROVAL_GATES.md` — milestones and deliverables.
17. `docs/15_QA_TESTING_AND_LAUNCH.md` — detailed checklists and acceptance.
18. `docs/16_CREATIVE_QUALITY_RUBRIC.md` — measurable reject/accept conditions.
19. `docs/17_DECISION_LOG_AND_OPEN_ITEMS.md` — living decisions, pending gaps.
20. `docs/18_CONTENT_AND_ASSET_REGISTERS.md` — approval system for private material.
21. `prompts/` — send one prompt per stage, **not all at once**.
22. `templates/` — specifications, implementation review and asset approval templates.
23. `scripts/` — optional local-only pre-deploy private-export/media approval scanner; does not replace human checks.

## Definition of success
A visually impressive, warm, playful, meaningful, technically well-made **original experience that could not be repurposed for a random recipient by changing her name**. Big spectacle plus small real details, not empty spectacle; emotion earned by truth, not repetitive AI-written sentimental speeches. Her choice to engage or not remains fully respected.

## Important limits of the package
- It contains **no complete Instagram exports, no actual photos, no user's gift/video files, no third-party private correspondence**.
- Dates/short quotations are **research references**, not permission to publish. Creator must approve each specific published excerpt.
- The ZIP **does not contain website code or auto-approved design images**. This is deliberate: the creative master concept has not been chosen yet.
- Some prior sketches described floating interfaces, a continuous canvas, and a 390 × 844 mockup: **none of these are approved final layouts**. The creator expressly rejected using one gimmick to dominate the whole site.
